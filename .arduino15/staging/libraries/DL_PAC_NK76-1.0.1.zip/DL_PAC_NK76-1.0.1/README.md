# DL_PAC_NK76
Arduino library for remote control DeLonghi PAC NK76

WORK IN PROGRESS!

Required IRremote library: https://github.com/z3t0/Arduino-IRremote

Usage:
- See example folder

TODO:
- Test timer function
